import java.util.Arrays;

public class ThreewayMergeSort {

    public static void main(String[] args) {
        int[] A = new int[]{3, 9, 10, 1, 8, 7, 5, 2};
        ThreewayMergeSort mergeSort = new ThreewayMergeSort();
        int[] sortedArray = mergeSort.threeWayMergeSort(A);
        System.out.print(Arrays.toString(sortedArray));
        // Expected output: [1, 2, 3, 5, 7, 8, 9, 10]
    }

    public int[] threeWayMergeSort(int[] array) {
        if (array == null || array.length <= 1) {
            return array;
        }

        int n = array.length;
        int[] left = Arrays.copyOfRange(array, 0, n / 3);
        int[] middle = Arrays.copyOfRange(array, n / 3, 2 * n / 3);
        int[] right = Arrays.copyOfRange(array, 2 * n / 3, n);

        left = threeWayMergeSort(left);
        middle = threeWayMergeSort(middle);
        right = threeWayMergeSort(right);

        return threeWayMerge(left, middle, right);
    }

    public int[] threeWayMerge(int[] a, int[] b, int[] c) {
        int[] temp = twoWayMerge(a, b);
        return twoWayMerge(temp, c);
    }

    public int[] twoWayMerge(int[] large, int[] small) {
        int[] merged = new int[large.length + small.length];
        int p1 = 0;
        int p2 = 0;
        int last = 0;

        while (p1 < large.length && p2 < small.length) {
            merged[last++] = large[p1] < small[p2] ? large[p1++] : small[p2++];
        }

        while (p1 < large.length) {
            merged[last++] = large[p1++];
        }

        while (p2 < small.length) {
            merged[last++] = small[p2++];
        }

        return merged;
    }
}
