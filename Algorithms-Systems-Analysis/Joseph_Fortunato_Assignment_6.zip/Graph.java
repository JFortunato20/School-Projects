import java.util.LinkedList;
import java.util.Random;
import java.util.Stack;

public class Graph {
    private int[][] edges;
    private LinkedList<Integer>[] adjlist;
    private Object[] labels;

    public Graph(int n) {
        edges = new int[n][n];
        adjlist = new LinkedList[n];
        labels = new Object[n];
    }

    public void setLabel(int vertex, Object label) {
        labels[vertex] = label;
    }

    public Object getLabel(int vertex) {
        return labels[vertex];
    }

    public int size() {
        return edges.length;
    }

    public void addEdge(int source, int target, int w) {
        edges[source][target] = w;
        edges[target][source] = w; // For undirected graph
    }

    public boolean isEdge(int source, int target) {
        return edges[source][target] > 0;
    }

    public void removeEdge(int source, int target) {
        edges[source][target] = 0;
        edges[target][source] = 0; // For undirected graph
    }

    public int getWeight(int source, int target) {
        return edges[source][target];
    }

    public int[] neighbors(int vertex) {
        int count = 0;
        for (int i = 0; i < edges[vertex].length; i++) {
            if (edges[vertex][i] > 0) count++;
        }
        final int[] answer = new int[count];
        count = 0;
        for (int i = 0; i < edges[vertex].length; i++) {
            if (edges[vertex][i] > 0) answer[count++] = i;
        }
        return answer;
    }

    public int getUnvisitedNeighbor(int vertex, boolean[] visited) {
        for (int i = 0; i < edges[vertex].length; i++) {
            if (edges[vertex][i] > 0 && !visited[i]) return i;
        }
        return -1;
    }

    public void getAdjList() {
        for (int i = 0; i < adjlist.length; i++) {
            adjlist[i] = new LinkedList<>();
            for (int j = 0; j < edges[i].length; j++) {
                if (edges[i][j] > 0) adjlist[i].add(j);
            }
        }
    }

    public void print() {
        int n = edges.length;
        for (int i = 0; i < n; i++) {
            System.out.println("Vertex " + i + ": " + adjlist[i].toString());
        }
    }

    public void dfs() {
        boolean[] visited = new boolean[edges.length];
        Stack<Integer> stack = new Stack<>();
        Random rand = new Random();
        int start = rand.nextInt(edges.length);

        stack.push(start);

        while (!stack.isEmpty()) {
            int current = stack.pop();

            if (!visited[current]) {
                System.out.println("Visited: " + labels[current]);
                visited[current] = true;

                // Iterate through all neighbors of the current vertex
                for (int neighbor : neighbors(current)) {
                    if (!visited[neighbor]) {
                        stack.push(neighbor);
                    }
                }
            }
        }
    }


    public static void main(String[] args) {
        final Graph t = new Graph(7);
        t.setLabel(0, "A");
        t.setLabel(1, "B");
        t.setLabel(2, "C");
        t.setLabel(3, "D");
        t.setLabel(4, "E");
        t.setLabel(5, "F");
        t.setLabel(6, "G");
        t.addEdge(0, 6, 1);
        t.addEdge(1, 0, 1);
        t.addEdge(2, 0, 1);
        t.addEdge(2, 3, 1);
        t.addEdge(4, 6, 1);
        t.addEdge(4, 3, 1);
        t.addEdge(4, 1, 1);
        t.addEdge(5, 0, 1);
        t.addEdge(5, 1, 1);
        t.addEdge(5, 3, 1);
        t.addEdge(6, 3, 1);
        t.getAdjList();
        t.print();

        System.out.println("DFS traversal:");
        t.dfs();
    }
}