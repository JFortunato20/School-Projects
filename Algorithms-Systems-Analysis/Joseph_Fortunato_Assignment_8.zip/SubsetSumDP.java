public class SubsetSumDP {

    public static boolean subsetSum(int[] A, int x) {

        boolean[][] Sum = new boolean[A.length + 1][x + 1];

        // Base case initialization: if sum is 0, then answer is true for all subsets
        for (int i = 0; i <= A.length; i++) {
            Sum[i][0] = true;
        }

        // Filling the Sum array using dynamic programming
        for (int i = 1; i <= A.length; i++) {
            for (int j = 1; j <= x; j++) {
                if (j < A[i - 1]) {
                    Sum[i][j] = Sum[i - 1][j];
                } else {
                    Sum[i][j] = Sum[i - 1][j] || Sum[i - 1][j - A[i - 1]];
                }
            }
        }

        return Sum[A.length][x];
    }

    public static void main(String[] args) {

        int[] A = {1, 3, 5, 2, 8};
        int x = 9;

        System.out.println("There exists a subset in A[] with sum = " + x + " : " + subsetSum(A, x));
        // Expected output: true
    }
}
