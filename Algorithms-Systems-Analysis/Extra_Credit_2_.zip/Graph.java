import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Graph {

    private int[][] edges;
    private LinkedList<Integer>[] adjlist;
    private Object[] labels;

    public Graph(int n) {
        edges = new int[n][n];
        adjlist = new LinkedList[n];
        labels = new Object[n];
        for (int i = 0; i < n; i++) {
            adjlist[i] = new LinkedList<>();
        }
    }

    public void setLabel(int vertex, Object label) {
        labels[vertex] = label;
    }

    public Object getLabel(int vertex) {
        return labels[vertex];
    }

    public int size() {
        return edges.length;
    }

    public void addEdge(int source, int target, int w) {
        edges[source][target] = w;
        adjlist[source].add(target); // Update adjacency list
    }

    public boolean isEdge(int source, int target) {
        return edges[source][target] > 0;
    }

    public void removeEdge(int source, int target) {
        edges[source][target] = 0;
    }

    public int getWeight(int source, int target) {
        return edges[source][target];
    }

    public int[] neighbors(int vertex) {
        LinkedList<Integer> neighborList = adjlist[vertex];
        int[] neighbors = new int[neighborList.size()];
        int i = 0;
        for (int neighbor : neighborList) {
            neighbors[i++] = neighbor;
        }
        return neighbors;
    }


    public void bfs() {
        boolean[] visited = new boolean[size()];
        Queue<Integer> queue = new LinkedList<>();

        // Choose a random starting vertex
        Random random = new Random();
        int startVertex = random.nextInt(size());

        // Enqueue the starting vertex and mark it as visited
        queue.offer(startVertex);
        visited[startVertex] = true;

        // Traverse the graph
        while (!queue.isEmpty()) {
            int currentVertex = queue.poll();
            System.out.println("Visited: " + getLabel(currentVertex));

            // Visit all unvisited neighbors of the current vertex
            for (int neighbor : neighbors(currentVertex)) {
                if (!visited[neighbor]) {
                    queue.offer(neighbor);
                    visited[neighbor] = true;
                }
            }
        }
    }
    public static void main(String[] args) {
        final Graph t = new Graph(6);
        t.setLabel(0, "A");
        t.setLabel(1, "B");
        t.setLabel(2, "C");
        t.setLabel(3, "D");
        t.setLabel(4, "E");
        t.setLabel(5, "F");
        t.addEdge(0, 1, 1);
        t.addEdge(0, 5, 1);
        t.addEdge(1, 2, 1);
        t.addEdge(1, 3, 1);
        t.addEdge(1, 5, 1);
        t.addEdge(2, 3, 1);
        t.addEdge(4, 3, 1);
        t.addEdge(4, 2, 1);
        t.addEdge(5, 4, 1);

        // Test BFS
        System.out.println("Breadth-First Search:");
        t.bfs();
    }
}
