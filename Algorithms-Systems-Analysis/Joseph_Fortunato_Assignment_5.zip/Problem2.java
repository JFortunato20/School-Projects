public class Problem2 {

    public static void swap(int[] A, int i, int j) {
        int temp = A[i];
        A[i] = A[j];
        A[j] = temp;
    }

    public static int[] partition(int[] A, int s, int e) {
        int pivot = A[s];
        int p = s;  // Initialize p to the start index
        int q = e;  // Initialize q to the end index
        int i = s;  // Initialize i to the start index

        while (i <= q) {
            if (A[i] < pivot) {
                swap(A, i++, p++);
            } else if (A[i] > pivot) {
                swap(A, i, q--);
            } else {
                i++;
            }
        }

        return new int[]{p, q};
    }

    // update the main method to use the returned indices from partition
    public static void main(String[] args) {
        int[] testarray1 = {1, 2, 4, 1, -5, -2, 0, 6, 3, 1, 7, 8};

        int[] indices = partition(testarray1, 0, testarray1.length - 1);

        // Output the array after the partition
        for (int i = 0; i < testarray1.length; i++) {
            System.out.print(testarray1[i] + " ");
        }
        System.out.println("\nIndices: " + indices[0] + ", " + indices[1]);
    }
}
