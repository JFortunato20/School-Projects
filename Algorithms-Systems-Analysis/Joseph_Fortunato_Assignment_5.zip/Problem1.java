import java.util.HashSet;
import java.util.Set;

public class Problem1 {

    public static void intersection(int[] s1, int[] s2) {
        // complete the intersection() method to output
        // elements that occur in both s1 and s2
        // feel free to change method type and parameters
        // Full credit will awarded to algorithms O(n) and in-place

        Set<Integer> set = new HashSet<>();
        System.out.print("Intersection of testarray1 and testarray2: ");
        for (int i : s1) {
            set.add(i);
        }
        for (int i : s2) {
            if (set.contains(i)) {
                System.out.print(i + " ");
                set.remove(i); // To handle duplicates
            }
        }
        System.out.println();
    }

    public static void union(int[] s1, int[] s2) {
        // complete the union() method to output
        // the union s1 and s2
        // feel free to change method type and parameters
        // Full credit will awarded to algorithms O(n) and in-place
        Set<Integer> set = new HashSet<>();
        System.out.print("Union of testarray1 and testarray2: ");
        for (int i : s1) {
            if (!set.contains(i)) {
                System.out.print(i + " ");
                set.add(i);
            }
        }
        for (int i : s2) {
            if (!set.contains(i)) {
                System.out.print(i + " ");
                set.add(i);
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Test your intersection() method here
        int[] testarray1 = {0, 0, 0, 1, 2, 3, 97, 98};
        int[] testarray2 = {0, 1, 2, 3, 4, 4, 10, 98, 100, 100};


        System.out.println("intersection of testarray1 and testarray2: ");
        intersection(testarray1,testarray2);
        //should output 0, 1, 2, 3, 98
        System.out.println("union of testarray1 and testarray2: ");
        union(testarray1,testarray2);
        //should output 0, 1, 2, 3, 4, 10, 97, 98, 100
    }

}