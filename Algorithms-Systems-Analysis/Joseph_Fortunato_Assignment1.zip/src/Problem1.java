import java.util.Arrays;
public class Problem1 {
    /*
Input: an array A[] of n integers and an integer value t.
Output: True if there exist three indices i, j and k, with 0 = i < j < k = n-1, such that A[i] + A[j] + A[k] = t, and False otherwise.
*/
    //Complete this method
    //Feel free to change the function return type, the parameters of the function
    public static boolean checksum(int[] A, int t)
    { // Sort the array
        Arrays.sort(A);

        // Iterate through the array using three pointers
        for (int i = 0; i < A.length - 2; i++) {
            int left = i + 1;
            int right = A.length - 1;

            while (left < right) {
                int sum = A[i] + A[left] + A[right];

                // Check if the current triplet has the desired sum
                if (sum == t) {
                    return true;
                } else if (sum < t) {
                    // If the sum is less than the target, move the left pointer to the right
                    left++;
                } else {
                    // If the sum is greater than the target, move the right pointer to the left
                    right--;
                }
            }
        }

        // No triplet found with the desired sum
        return false;
    }

    public static void main(String[] args) {

        // Test your checksum method

        int[] A = {28, -70, -23, 92, 56, -33, -77};
        int t = -47;
        System.out.println("There exist three indices i, j and k, such that A[i] + A[j] + A[k] =" + t + " : " + checksum(A,t));
        // Expected output: True

        // Feel free to add more test cases



    }
}
