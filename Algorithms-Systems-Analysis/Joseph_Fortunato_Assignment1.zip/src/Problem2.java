import java.util.Arrays;

public class Problem2 {
    /*
		There is an array A[] that consists of n integers and these integers are not in any particular order. There are no duplicates in A[]. There is another array B[] that contains the same set of elements as A[], but one element is missing.
		Output: Find the missing integer.
		Design an algorithm that solves this problem.
		*/

    // Complete this method
    public static int missingnumber(int[] A, int[] B) {
        // Sort both arrays
        Arrays.sort(A);
        Arrays.sort(B);

        // Iterate through arrays to find the missing number
        int i = 0, j = 0;
        while (i < A.length && j < B.length) {
            if (A[i] != B[j]) {
                // Found the missing number
                return A[i];
            }
            i++;
            j++;
        }

        // Check remaining elements in A
        while (i < A.length && A[i] == B[j - 1]) {
            i++;
        }
        if (i < A.length) {
            return A[i];
        }

        // Check remaining elements in B
        while (j < B.length && B[j] == A[i - 1]) {
            j++;
        }
        if (j < B.length) {
            return B[j];
        }

        // If no missing number is found, return a sentinel value
        return -1;
    }

    public static void main(String[] args) {
        int[] A = {5, 7, 10, 9, 23, 1, 13, 100};;
        int[] B =  {100, 7, 5, 13, 1, 9, 10};

        int missingNumber = missingnumber(A, B);
        if (missingNumber != -1) {
            System.out.println("The missing number is: " + missingNumber);
        } else {
            System.out.println("No missing number found.");
        }
    }
}
