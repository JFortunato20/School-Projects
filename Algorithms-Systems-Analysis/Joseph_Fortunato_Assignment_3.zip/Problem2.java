public class Problem2 {
    //Joseph Fortunato
    //2.20.2023
    //CMPT 435 111
    public static int countDigit(int num) {
        if (num == 0) {
            return 1; // Special case: 0 has 1 digit
        }
        return countDigitHelper(num);
    }

    private static int countDigitHelper(int num) {
        if (num == 0) {
            return 0; // Base case: no more digits left
        }
        return 1 + countDigitHelper(num / 10); // Count the current digit and recur for the remaining digits
    }

    public static void main(String[] args) {
        // test your Countdigit() method here
        System.out.println(countDigit(1234));
        // 4 expected
        System.out.println(countDigit(491526));
        // 6 expected
    }
}
