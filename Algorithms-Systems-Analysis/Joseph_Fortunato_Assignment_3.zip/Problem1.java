public class Problem1 {
    //Joseph Fortunato
    //2.19.2023
    //CMPT 435 111
    public static int largest(int[] A) {
        // complete the method from here
        // input: an array A[]
        // output: the largest element in A[]
        // a recursive function that does not contain a loop
        // feel free to change the function return type and the parameters
        return largestHelper(A, 0, A.length - 1);
    }

    private static int largestHelper(int[] A, int start, int end) {
        if (start == end) {
            return A[start];
        }

        int mid = (start + end) / 2;
        int leftMax = largestHelper(A, start, mid);
        int rightMax = largestHelper(A, mid + 1, end);

        return Math.max(leftMax, rightMax);
    }

    public static void main(String[] args) {
        // test your largest() method here
        int[] testarray = {12,25,36,85,28};
        System.out.println(largest(testarray));
        // 85 expected


    }
}