public class ContiguousSumDP {

    public static int MaximumSumContSubsequence(int[] A) {
        int n = A.length;
        int[] Local_maximum = new int[n];
        Local_maximum[0] = A[0];
        int maxSum = A[0]; // Initialize maxSum to the first element of the array

        // Dynamic programming loop
        for (int i = 1; i < n; i++) {
            // The maximum sum ending at index i is either the element itself or the element combined with the previous maximum sum
            Local_maximum[i] = Math.max(A[i], Local_maximum[i - 1] + A[i]);
            // Update the global maximum sum if needed
            maxSum = Math.max(maxSum, Local_maximum[i]);
        }

        return maxSum; // Return the maximum sum of contiguous subsequence
    }

    public static void main(String[] args) {
        int[] A = {-2, 1, -3, 4, -1, 2, 1, -5, 4};

        System.out.println("The maximum sum of contiguous subsequence in A[] = " + MaximumSumContSubsequence(A));
        //Given the array [−2,1,−3,4,−1,2,1,−5,4], the contiguous subarray [4,−1,2,1] has the largest sum = 6.
    }
}
