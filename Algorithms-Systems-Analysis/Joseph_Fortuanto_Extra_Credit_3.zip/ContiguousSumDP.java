public class ContiguousSumDP {

    public static int MaximumSumContSubsequence(int[] A) {
        int n = A.length;
        if (n == 0) return 0;

        int[] Local_maximum = new int[n];
        Local_maximum[0] = A[0];

        int maxSum = A[0]; // Initialize the maximum sum

        // Calculate Local_maximum(i) for each index i
        for (int i = 1; i < n; i++) {
            // Calculate Local_maximum(i) based on the principle provided
            Local_maximum[i] = Math.max(A[i], A[i] + Local_maximum[i - 1]);

            // Update the maximum sum found so far
            maxSum = Math.max(maxSum, Local_maximum[i]);
        }

        return maxSum; // Return the maximum sum found
    }

    public static void main(String[] args) {
        int[] A = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
        System.out.println("The maximum sum of contiguous subsequence in A[] = " +  MaximumSumContSubsequence(A));
        //Given the array [−2,1,−3,4,−1,2,1,−5,4], the contiguous subarray [4,−1,2,1] has the largest sum = 6.
    }
}
