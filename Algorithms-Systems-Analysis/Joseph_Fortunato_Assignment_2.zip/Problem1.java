public class Problem1 {

    public static boolean findi(int[] A)
    {
        // given an array A of n integers
        // return true if there exists an index i such that A[i] = i
        // false otherwise
        // complete the method findi() here
        // O(log n) time expected
        // Algorithms slower than O(logn) will be graded out of 10 points
        // feel free to change the return type or parameters

        int left = 0;
        int right = A.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (A[mid] == mid) {
                return true;
            } else if (A[mid] < mid) {
                // If A[mid] < mid, the desired index i must be in the right half
                left = mid + 1;
            } else {
                // If A[mid] > mid, the desired index i must be in the left half
                right = mid - 1;
            }
        }

        return false;
    }
    public static void main(String[] args) {
        // test your maximum() method here

        int[] testarray = {-4, 0, 2, 5, 10, 27, 39, 52};

        System.out.println("There exists an index i in the input array that A[i] = i "+ findi(testarray));
        // true expected


    }

}

