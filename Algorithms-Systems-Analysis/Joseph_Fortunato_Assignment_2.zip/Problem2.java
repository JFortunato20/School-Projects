public class Problem2 {

    public static int count(double[] A, double x)
    {
        // given a sorted array A, and a value x, return the number of times x occurs in A
        // complete the method count() here
        // O(log n) expected
        // Algorithms slower than O(logn) will be graded out of 10 points
        // feel free to change the return type or parameters

        int firstIndex = findFirstIndex(A, x);
        int lastIndex = findLastIndex(A, x);

        if (firstIndex == -1 || lastIndex == -1)
            return 0;

        return lastIndex - firstIndex + 1;
    }

        private static int findFirstIndex(double[] A, double x) {
        int left = 0;
        int right = A.length - 1;
        int result = -1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (A[mid] == x) {
                result = mid;
                right = mid - 1; // Continue searching in the left half for the first occurrence
            } else if (A[mid] < x) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return result;
    }

        private static int findLastIndex(double[] A, double x) {
        int left = 0;
        int right = A.length - 1;
        int result = -1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (A[mid] == x) {
                result = mid;
                left = mid + 1; // Continue searching in the right half for the last occurrence
            } else if (A[mid] < x) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return result;
    }





    public static void main(String[] args) {
        // test your count() method here

        double[] testarray = {1.3, 2.1, 2.1, 2.1, 2.1, 6.7, 7.5, 7.5, 8.6, 9.0};
        double t1 = 2.1;
        double t2 = 7.5;
        double t3 = 1.3;
        System.out.println(t1+" appears "+ count(testarray, t1) + " times");
        // 4 expected
        System.out.println(t2+" appears "+ count(testarray, t2) + " times");
        // 2 expected
        System.out.println(t3+" appears "+ count(testarray, t3) + " times");
        // 1 expected


    }

}
