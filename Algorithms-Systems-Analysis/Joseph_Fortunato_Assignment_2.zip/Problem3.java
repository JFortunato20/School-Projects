public class Problem3 {

    public static int squareroot(int x) {
        // given a positive integer x, return square root of x
        // if x is not a perfect square, return the floor of its square root
        // complete the method squareroot() here
        // O(log n) expected
        // Algorithms slower than O(logn) will be graded out of 10 points
        // feel free to change the return type or parameters

            if (x == 0 || x == 1)
                return x;

            int left = 1;
            int right = x;
            int result = 0;

            while (left <= right) {
                int mid = left + (right - left) / 2;

                // Check if the square of mid is equal to x
                if (mid == x / mid) {
                    return mid;
                }

                // If mid * mid is less than or equal to x, update result and move towards right subarray
                if (mid <= x / mid) {
                    left = mid + 1;
                    result = mid;
                } else {
                    // If mid * mid is greater than x, move towards left subarray
                    right = mid - 1;
                }
            }

            return result;
        }

    public static void main(String[] args) {
        // test your squareroot() method here

        int x1 = 9;
        int x2 = 5;
        int x3 = 17;
        System.out.println("The square root of " + x1 + " is " + squareroot(x1));
        // 3 expected
        System.out.println("The square root of " + x2 + " is " + squareroot(x2));
        // 2 expected
        System.out.println("The square root of " + x3 + " is " + squareroot(x3));
        // 4 expected


    }

}