var TSOS;
(function (TSOS) {
    class PCB {
        pid;
        constructor(pid) {
            this.pid = pid;
        }
        // CPU registers
        pc = 0;
        ir = "00";
        acc = 0;
        x = 0;
        y = 0;
        z = 0;
        // Mem Partition
        base = 0x000;
        limit = 0x0FF;
        segment = -1; //0,1,2
        //scheduling
        state = "Ready";
        priority = 0; // (future use)
        quantumRemaining = 0;
        // --- metrics (cpu cycles) ---
        cyclesTotal = 0; // time spent running on CPU
        cyclesWaiting = 0; // time spent in Ready queue
        createdAt = _OSclock; // optional wall clock stamp
        finishedAt = null; // when finished (optional)
        // --- project 4: swapping metadata ---
        location = "Memory";
        swapFilename = null;
    }
    TSOS.PCB = PCB;
})(TSOS || (TSOS = {}));
//# sourceMappingURL=pcb.js.map