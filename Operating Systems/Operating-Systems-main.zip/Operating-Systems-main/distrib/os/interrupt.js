/* ------------
   Interrupt.ts
   ------------ */
var TSOS;
(function (TSOS) {
    class Interrupt {
        irq;
        params;
        constructor(irq, params) {
            this.irq = irq;
            this.params = params;
        }
        static CONTEXT_SWITCH_IRQ = 0x99; // pick an unused number        
    }
    TSOS.Interrupt = Interrupt;
    TSOS.CONTEXT_SWITCH_IRQ = 99; // pick any unused number
})(TSOS || (TSOS = {}));
//# sourceMappingURL=interrupt.js.map