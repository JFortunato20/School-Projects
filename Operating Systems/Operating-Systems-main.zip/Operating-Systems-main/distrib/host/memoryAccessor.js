/* ==== memoryAccessor.ts ==== */
var TSOS;
(function (TSOS) {
    class MemoryAccessor {
        translate(logical) {
            const pcb = _Scheduler.getCurrentPcb();
            if (!pcb)
                _Kernel.krnTrapError("No current process for memory access");
            const phys = pcb.base + (logical & 0xFF);
            if (phys < pcb.base || phys > pcb.limit) {
                _Kernel.krnTrapError(`Memory access violation at logical ${logical.toString(16)} (phys ${phys.toString(16)})`);
            }
            return phys;
        }
        read(logical) { return _Memory.read(this.translate(logical)); }
        write(logical, value) { _Memory.write(this.translate(logical), value & 0xFF); }
    }
    TSOS.MemoryAccessor = MemoryAccessor;
})(TSOS || (TSOS = {}));
var _MemoryAccessor = new TSOS.MemoryAccessor();
//# sourceMappingURL=memoryAccessor.js.map